[[+ Start Here|Home]]

>As members of The Church of Jesus Christ of Latter-day Saints, we are blessed to be led by living prophets—inspired men called to speak for the Lord, as did Moses, Isaiah, Peter, Paul, Nephi, Mormon, and other prophets of the scriptures. We sustain the President of the Church as prophet, seer, and revelator—the only person on the earth who receives revelation to guide the entire Church. We also sustain the counselors in the First Presidency and the members of the Quorum of the Twelve Apostles as prophets, seers, and revelators.
>
>Like the prophets of old, prophets today testify of Jesus Christ and teach His gospel. They make known God’s will and true character. They speak boldly and clearly, denouncing sin and warning of its consequences. At times, they may be inspired to prophesy of future events for our benefit.
>
>We can always trust the living prophets. Their teachings reflect the will of the Lord, who declared: “What I the Lord have spoken, I have spoken, and I excuse not myself; and though the heavens and the earth pass away, my word shall not pass away, but shall all be fulfilled, whether by mine own voice or by the voice of my servants, it is the same” ([Doctrine and Covenants 1:38](https://www.churchofjesuschrist.org/study/scriptures/dc-testament/dc/1.38?lang=eng#p38)).
>
>Our greatest safety lies in strictly following the word of the Lord given through His prophets, particularly the current President of the Church. The Lord warns that those who ignore the words of the living prophets will fall (see [Doctrine and Covenants 1:14–16](https://www.churchofjesuschrist.org/study/scriptures/dc-testament/dc/1.14-16?lang=eng#p14)). He promises great blessings to those who follow the President of the Church:
>
>“Thou shalt give heed unto all his words and commandments which he shall give unto you as he receiveth them, walking in all holiness before me;
>
>“For his word ye shall receive, as if from mine own mouth, in all patience and faith.
>
>“For by doing these things the gates of hell shall not prevail against you; yea, and the Lord God will disperse the powers of darkness from before you, and cause the heavens to shake for your good, and his name’s glory” ([Doctrine and Covenants 21:4–6](https://www.churchofjesuschrist.org/study/scriptures/dc-testament/dc/21.4-6?lang=eng#p4)).

---
[Prophets](https://www.churchofjesuschrist.org/study/manual/gospel-topics/prophets?lang=eng)