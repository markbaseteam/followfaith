[[+ Start Here|Home]]

# Why Is It Important To Follow The Prophet?

We’re living in the last days of the final dispensation; the Second Coming of the Lord Jesus Christ isn’t far away.

The battle for the souls of every one of us is real! It continues at an frighteningly rapid pace as Satan deploys every subtle, personally-tailored genius scheme to convince us to loosen our hold on the iron rod. He knows us better than we know ourselves, but not as well as our Father in heaven!

God’s aim: to bring about our immortality and eternal life, through the Atonement of His only Begotten Son.

Satan’s aim: to bring about our eternal misery, through deception and false promises.

The Lord has appointed a prophet to lead the people of His church, and speak to us on His behalf.
