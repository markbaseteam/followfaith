![[Pasted image 20220529213443.png]]
# Wakeful Following—Spiritual Lifelines For Sincere Truth-Seekers
This site is dedicated to the study of what it means to follow the [[Prophets of God|prophet]] God has appointed to lead His people in these latter days, and how to remain faithful when personal opinions differ from the official position of the Church.

## Follow the Prophet, Avoid Regret
[[Why Is It Important To Follow The Prophet?]]

## Scriptures

## Quotes



---
*This collection of thoughts and information has been gathered with the intent to build faith in the Lord Jesus Christ, and His restored Church, but is in no way associated with [The Church of Jesus Christ of Latter-day Saints](https://www.churchofjesuschrist.org/?lang=eng).* 